package cz.rezim.app

import android.view.View
import androidx.core.view.HapticFeedbackConstantsCompat
import androidx.core.view.ViewCompat

// Use a distinct confirmation pulse instead of a subtle text-cursor movement tick.
// AndroidX maps it on older Android versions and respects system touch-feedback settings.
internal fun performSetHaptic(view: View): Boolean =
    ViewCompat.performHapticFeedback(view, HapticFeedbackConstantsCompat.CONFIRM)
