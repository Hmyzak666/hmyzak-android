package cz.rezim.app

import android.app.Application
import androidx.compose.runtime.*
import androidx.lifecycle.AndroidViewModel
import java.time.LocalDate
import java.time.DayOfWeek

enum class Page(val title: String, val short: String) {
    HOME("Přehled", "Domů"), STRENGTH("Síla", "Síla"), RUN("Běh", "Běh"), HIIT("HIIT", "HIIT"), BODY("Míry", "Míry")
}

class RezimState(application: Application) : AndroidViewModel(application) {
    private val db=LocalStore(application)
    var page by mutableStateOf(Page.HOME)
    var runFormRequest by mutableIntStateOf(0)
        private set
    var hiitFormRequest by mutableIntStateOf(0)
        private set
    var days by mutableStateOf<List<DayPlan>>(emptyList())
        private set
    fun plan(key:String):DayPlan = days.first {it.key==key}
    fun partner(key:String):String? = plan(selectedDay).exercises.firstOrNull{it.key==key}?.partnerKey
    fun startRunForm() { page=Page.RUN;runFormRequest++ }
    fun startHiitForm() { page=Page.HIIT;hiitFormRequest++ }
    var selectedDay by mutableStateOf(when(LocalDate.now().dayOfWeek) {
        DayOfWeek.TUESDAY -> "tue"
        DayOfWeek.WEDNESDAY -> "wed"
        DayOfWeek.FRIDAY -> "fri"
        DayOfWeek.SUNDAY -> "sun"
        else -> "mon"
    })
        private set
    var session by mutableStateOf<Session?>(null)
        private set
    val workoutSets = mutableStateListOf<SetEntry>()
    val previous = mutableStateMapOf<String,SetEntry?>()
    var editingSavedWorkout by mutableStateOf<Session?>(null)
        private set
    val editingSavedSets = mutableStateListOf<SetEntry>()
    fun beginEditSavedWorkout(record:Session) {
        if(session!=null) {tell("Nejdřív dokonči nebo ulož rozpracovaný trénink.");return}
        if(record.finished==null) return
        editingSavedWorkout=record
        editingSavedSets.clear();editingSavedSets.addAll(db.sets(record.id))
        page=Page.STRENGTH
    }
    fun setSavedEntry(entry:SetEntry,weight:String?=null,reps:String?=null,done:Boolean?=null) {
        val i=editingSavedSets.indexOfFirst{it.id==entry.id}
        if(i<0) return
        val old=editingSavedSets[i]
        editingSavedSets[i]=old.copy(weight=weight?:old.weight,reps=reps?:old.reps,done=done?:old.done)
    }
    fun cancelSavedEdit() {editingSavedWorkout=null;editingSavedSets.clear()}
    fun commitSavedEdit() {
        val record=editingSavedWorkout?:return
        try {
            db.saveFinishedWorkout(record.id,editingSavedSets.toList())
            cancelSavedEdit();refresh();tell("Uložený trénink opraven.")
        } catch(e:Exception) {tell(e.localizedMessage?:"Změny se nepodařilo uložit.")}
    }
    fun updateRun(r:RunEntry) {db.updateRun(r);refresh();tell("Běh opraven.")}
    fun updateHiit(r:HiitEntry) {db.updateHiit(r);refresh();tell("HIIT opraven.")}
    fun updateMeasure(r:MeasureEntry) {db.updateMeasure(r);refresh();tell("Měření opraveno.")}

    var runs by mutableStateOf<List<RunEntry>>(emptyList())
        private set
    var hiit by mutableStateOf<List<HiitEntry>>(emptyList())
        private set
    var measures by mutableStateOf<List<MeasureEntry>>(emptyList())
        private set
    var recentWorkouts by mutableStateOf<List<Session>>(emptyList())
        private set
    var totalWorkouts by mutableIntStateOf(0)
        private set
    var message by mutableStateOf<String?>(null)
        private set
    init {
        refresh()
        // Restore an unfinished session after a process kill or a phone reboot.
        selectDay(db.firstOpenSession()?.day ?: selectedDay)
    }
    fun clearMessage() { message=null }
    fun tell(text:String) { message=text }
    fun refresh() {
        days=db.plans()
        runs=db.runs(); hiit=db.hiit(); measures=db.measures()
        recentWorkouts=db.recentSessions(); totalWorkouts=db.countSessions()
    }
    fun selectDay(day:String) {
        if(days.none{it.key==day}) { if(days.isNotEmpty()) selectDay(days.first().key); return }
        val open=db.firstOpenSession()
        if(open!=null && open.day!=day) {
            selectedDay=open.day
            session=open
            tell("Nejdřív dokonči nebo zahoď rozpracovaný trénink.")
            return
        }
        selectedDay=day; session=db.openSession(day)
        workoutSets.clear()
        session?.let { workoutSets.addAll(db.sets(it.id)) }
        previous.clear()
        for (ex in plan(day).exercises) for (n in 1..ex.sets) {
            previous["${ex.key}:$n"] = db.previous(day,ex.key,n)
        }
    }
    fun start() {
        if(plan(selectedDay).exercises.isEmpty()) {tell("Nejdřív přidej cvik.");return}
        val other=db.firstOpenSession()
        if(other!=null && other.day!=selectedDay) {
            selectDay(other.day); tell("Nejprve dokonči nebo zahoď rozpracovaný trénink."); return
        }
        session=db.beginWorkout(selectedDay); selectDay(selectedDay)
    }
    fun discardWorkout() {
        val open=session ?: return
        db.deleteOpenWorkout(open.id)
        selectDay(selectedDay);refresh();tell("Rozpracovaný trénink zahozen.")
    }
    fun updateExerciseDetails(key:String,name:String,note:String) {
        if(session!=null) {tell("Úpravy cviků jsou dostupné po ukončení tréninku.");return}
        if(name.isBlank()) {tell("Název cviku nesmí být prázdný.");return}
        db.updateExerciseDetails(selectedDay,key,name,note)
        refresh();selectDay(selectedDay);tell("Název a poznámka uloženy.")
    }
    fun createDay(name:String) {
        if(name.isBlank()) {tell("Zadej název dne.");return}
        if(days.size>=20) {tell("Limit je 20 šablon.");return}
        val id=db.addDay(name);refresh();selectDay(id);tell("Tréninkový den přidán.")
    }
    fun addExercise(name:String,sets:Int,type:UnitType) {
        if(session!=null) {tell("Před úpravou dokonči rozepsaný trénink.");return}
        if(name.isBlank() || sets !in 1..15) {tell("Zadej název a 1–15 sérií.");return}
        db.addExercise(selectedDay,name,sets,type);refresh();selectDay(selectedDay)
    }
    fun moveExercise(key:String,offset:Int) {
        if(session!=null) {tell("Před úpravou dokonči rozepsaný trénink.");return}
        db.moveExercise(selectedDay,key,offset);refresh();selectDay(selectedDay)
    }
    fun removeExercise(key:String) {
        if(session!=null) {tell("Před úpravou dokonči rozepsaný trénink.");return}
        db.removeExercise(selectedDay,key);refresh();selectDay(selectedDay)
    }
    fun deleteDay() {
        if(session!=null) {tell("Před odstraněním dokonči rozepsaný trénink.");return}
        if(days.size<=1) {tell("Musí zůstat alespoň jeden tréninkový den.");return}
        val old=selectedDay;db.removeDay(old);refresh();selectDay(days.first().key)
    }
    fun updatePair(a:String,b:String?) {
        if(session!=null) {tell("Před úpravou dokonči rozepsaný trénink.");return}
        db.pair(selectedDay,a,b);refresh();selectDay(selectedDay)
    }
    fun exerciseTrend(key:String,showWeight:Boolean):List<Pair<String,Double>> {
        val sessions=db.recentSessions(400).filter {it.day==selectedDay}.asReversed()
        return sessions.mapNotNull { sess ->
            val sets=db.sets(sess.id).filter {it.exercise==key && it.done}
            if(sets.isEmpty()) null else {
                val max=sets.mapNotNull {it.weight.asNumber()}.maxOrNull() ?: 0.0
                val total=sets.sumOf {it.reps.toIntOrNull() ?: 0}
                val date=java.time.Instant.ofEpochMilli(sess.finished?:sess.created)
                    .atZone(java.time.ZoneId.systemDefault()).toLocalDate().toString()
                date to (if(showWeight) max else total.toDouble())
            }
        }.takeLast(16)
    }
    enum class ExportScope { RECENT, PREVIOUS_WEEK, ALL }

    // Monday morning export: previous Mon-Sun workouts, plus current Monday's check-in.
    fun shareSummary(scope:ExportScope=ExportScope.RECENT):String = buildString {
        val today=LocalDate.now()
        val thisMonday=today.minusDays((today.dayOfWeek.value-1).toLong())
        val from=thisMonday.minusDays(7)
        val until=thisMonday.minusDays(1)
        val finishedSessions=when(scope) {
            ExportScope.RECENT -> db.recentSessions(7)
            ExportScope.PREVIOUS_WEEK -> db.allSessions().filter {
                val date=java.time.Instant.ofEpochMilli(it.finished?:it.created)
                    .atZone(java.time.ZoneId.systemDefault()).toLocalDate()
                !date.isBefore(from) && !date.isAfter(until)
            }
            ExportScope.ALL -> db.allSessions()
        }
        fun dateInWeek(date:String):Boolean = runCatching {
            val d=LocalDate.parse(date);!d.isBefore(from) && !d.isAfter(until)
        }.getOrDefault(false)
        val chosenRuns=when(scope) {
            ExportScope.RECENT->runs.take(5)
            ExportScope.PREVIOUS_WEEK->runs.filter{dateInWeek(it.date)}
            ExportScope.ALL->runs
        }
        val chosenHiit=when(scope) {
            ExportScope.RECENT->hiit.take(3)
            ExportScope.PREVIOUS_WEEK->hiit.filter{dateInWeek(it.date)}
            ExportScope.ALL->hiit
        }
        val chosenMeasures=when(scope) {
            ExportScope.RECENT->measures.take(3)
            ExportScope.PREVIOUS_WEEK->measures.filter {dateInWeek(it.date) || (today.dayOfWeek==DayOfWeek.MONDAY && it.date==today.toString())}
            ExportScope.ALL->measures
        }
        appendLine("HMYZÁK · tréninkový výpis (jen čtení, sdílený uživatelem)")
        appendLine("Datum exportu: $today")
        appendLine(when(scope) {
            ExportScope.RECENT -> "Rozsah: poslední záznamy"
            ExportScope.PREVIOUS_WEEK -> "Rozsah: minulý týden $from až $until; plus pondělní měření, pokud existuje"
            ExportScope.ALL -> "Rozsah: celá historie"
        })
        appendLine("Silové tréninky (${finishedSessions.size}):")
        if(finishedSessions.isEmpty()) appendLine("Žádný dokončený silový trénink.")
        finishedSessions.forEach {sess ->
            val date=java.time.Instant.ofEpochMilli(sess.finished?:sess.created)
                .atZone(java.time.ZoneId.systemDefault()).toLocalDate()
            appendLine("$date | ${days.firstOrNull{it.key==sess.day}?.name ?: sess.day}")
            db.sets(sess.id).filter{it.done}.groupBy{it.exercise}.forEach { (key,sets) ->
                val exercise=days.flatMap{it.exercises}.firstOrNull{it.key==key}
                val name=exercise?.name ?: key
                appendLine("- $name: ${sets.joinToString("; "){set ->
                    val w= when {
                        set.weight=="0" && (exercise?.type==UnitType.ADDED_KG || key.contains("calf",true)) -> "0 kg (vlastní váha) × "
                        set.weight.isNotBlank() -> "${set.weight} kg × "
                        else -> ""
                    }
                    w+set.reps+" op."
                }}")
            }
        }
        appendLine("Běhy (${chosenRuns.size}):")
        chosenRuns.forEach {r->appendLine("${r.date}: ${fmtNumber(r.km)} km, ${r.seconds}s, tep Ø ${r.avg?:"–"}, max ${r.max?:"–"}${if(r.note.isNotBlank()) ", pozn.: ${r.note}" else ""}")}
        appendLine("HIIT (${chosenHiit.size}):")
        chosenHiit.forEach {r->appendLine("${r.date}: ${r.minutes} min, ${r.rounds} kol, ${r.work}s práce / ${r.rest}s odpočinek, tep Ø ${r.avg?:"–"}, max ${r.max?:"–"}${if(r.note.isNotBlank()) ", pozn.: ${r.note}" else ""}")}
        appendLine("Měření (${chosenMeasures.size}):")
        chosenMeasures.forEach{m->appendLine("${m.date}: ${fmtNumber(m.kg)} kg, břicho ${fmtNumber(m.waist)} cm")}
    }
    fun changeSet(entry: SetEntry, weight: String?=null, reps: String?=null) {
        val idx=workoutSets.indexOfFirst { it.id==entry.id }
        if(idx<0) return
        val base=workoutSets[idx]
        val next=base.copy(weight=weight ?: base.weight, reps=reps ?: base.reps)
        workoutSets[idx]=next
        db.updateSet(next)
    }
    fun toggle(entry: SetEntry, type: UnitType):Boolean {
        val idx=workoutSets.indexOfFirst { it.id==entry.id }
        if(idx<0) return false
        val current=workoutSets[idx].let {entry ->
            if(!entry.done && entry.weight.isBlank() && entry.exercise.contains("calf",true)) entry.copy(weight="0") else entry
        }
        if (!current.done) {
            val r=current.reps.toIntOrNull()
            if(r==null || r<=0) { tell("Nejdřív zadej počet opakování."); return false }
            if(type==UnitType.KG && (current.weight.asNumber() ?: -1.0)<0.0) { tell("Zadej zátěž (0 kg = vlastní váha)."); return false }
            if(type==UnitType.ADDED_KG && (current.weight.asNumber() ?: -1.0)<0.0) { tell("Zadej přidanou zátěž (0 kg bez zátěže)."); return false }
        }
        val next=current.copy(done=!current.done)
        workoutSets[idx]=next; db.updateSet(next)
        return next.done
    }
    fun finish() {
        val s=session ?: return
        if(!workoutSets.any { it.done }) { tell("Nejdřív dokonči alespoň jednu sérii."); return }
        db.finishWorkout(s.id)
        selectDay(selectedDay); refresh(); tell("Trénink uložen.")
    }
    fun addRun(date:String,km:Double,seconds:Int,avg:Int?,max:Int?,note:String) {
        db.addRun(date,km,seconds,avg,max,note); refresh(); tell("Běh uložen.")
    }
    fun addHiit(date:String,minutes:Int,rounds:Int,work:Int,rest:Int,avg:Int?,max:Int?,note:String) {
        db.addHiit(date,minutes,rounds,work,rest,avg,max,note); refresh(); tell("HIIT uložen.")
    }
    fun addMeasure(date:String,kg:Double,waist:Double) {
        db.addMeasure(date,kg,waist); refresh(); tell("Měření uloženo.")
    }
    fun exportBackup():String = db.exportJson()
    fun importBackup(text:String) {
        db.importJson(text); refresh(); selectDay(selectedDay)
        tell("Záloha obnovena.")
    }
    override fun onCleared() { db.close(); super.onCleared() }
}
