# Oprava sestaveni Hmyzaka v0.4

Tento archiv nahrazuje cely v0.4 aktualizacni archiv a pridava
chybejici app/src/main/java/cz/rezim/app/Plans.kt.
Opravuje chyby v konstruktoru Exercise a referencich na note.
Nazev souboru v00.4 je zvoleny kvuli vyberu archivu v soucasnem
GitHub Actions workflow, ktery pri shodnem cisle verze vybere
lexikograficky vyssi nazev. APK nadale ponese verzi 0.4.x.
Puvodni v0.4 ZIP ani soubory uzivatele na telefonu se nemeni.
